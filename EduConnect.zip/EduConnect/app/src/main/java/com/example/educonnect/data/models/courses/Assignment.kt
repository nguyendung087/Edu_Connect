package com.example.educonnect.data.models.courses

import kotlinx.datetime.LocalDateTime
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Assignment(
    @SerialName("assignment_id")
    val assignmentId: String = "",
    @SerialName("course_id")
    val courseId: String = "",
    val title: String = "",
    val description: String = "",
    @SerialName("assign_time")
    val assignTime: LocalDateTime = LocalDateTime(1990, 1, 1, 1, 1,1),
    val deadline: LocalDateTime = LocalDateTime(1990, 1, 1, 1, 1,1),
    val type: String = ""
)
