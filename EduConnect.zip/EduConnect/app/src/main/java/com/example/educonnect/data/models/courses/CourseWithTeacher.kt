package com.example.educonnect.data.models.courses

import com.example.educonnect.data.models.users.TeacherProfile
import kotlinx.serialization.Serializable

@Serializable
data class CourseWithTeacher(
    val course: Course = Course(),
    val teacher: TeacherProfile = TeacherProfile()
)