package com.example.educonnect.data.models.courses

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Enrollment(
    @SerialName("student_id")
    val studentId: String = "",
    @SerialName("course_id")
    val courseId: String = "",
    val status: String = "Ongoing",
    val progress: Float = 0.0f
)