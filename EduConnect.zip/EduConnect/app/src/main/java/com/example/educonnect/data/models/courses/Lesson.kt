package com.example.educonnect.data.models.courses

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Lesson(
    @SerialName("lesson_id")
    val lessonId: String = "",
    @SerialName("course_id")
    val courseId: String = "",
    val title: String = "",
    val content: String = "",
    val type: String = "",
    @SerialName("file_url")
    val fileUrl: String = "abc"
)