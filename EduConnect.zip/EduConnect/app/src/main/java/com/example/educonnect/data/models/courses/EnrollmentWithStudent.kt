package com.example.educonnect.data.models.courses

import com.example.educonnect.data.models.users.StudentProfile
import kotlinx.serialization.Serializable

@Serializable
data class EnrollmentWithStudent(
    val enrollment : Enrollment = Enrollment(),
    val student : StudentProfile = StudentProfile()
)