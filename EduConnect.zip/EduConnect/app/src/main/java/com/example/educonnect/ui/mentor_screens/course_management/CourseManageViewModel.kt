package com.example.educonnect.ui.mentor_screens.course_management

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.courses.Lesson
import com.example.educonnect.data.models.users.TeacherProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.count
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CourseManageViewModel(
    private val supabase : SupabaseClient
) : ViewModel() {
    private var _courseUiState = MutableStateFlow(CourseManageUiState())
    val courseUiState : StateFlow<CourseManageUiState> = _courseUiState.asStateFlow()

    fun loadCourseWithTeacher(teacherId: String?) {
        if (teacherId == null) return

        viewModelScope.launch {
            try {
                val courses = supabase.from("courses")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeList<Course>()

                val teachers = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeList<TeacherProfile>()

                val courseWithTeachers = courses.map { course ->
                    val teacher = teachers.find { it.teacherId == course.teacherId }
                    CourseWithTeacher(course, teacher ?: TeacherProfile())
                }

                _courseUiState.update { currentState -> currentState.copy(courseWithTeacherList = courseWithTeachers) }

                courses.forEach { course ->
                    val lessonCount = supabase.from("lessons")
                        .select { filter { eq("course_id", course.courseId) } }
                        .decodeList<Lesson>().size
                    _courseUiState.update { currentState -> currentState.copy(lessonCounts = lessonCount) }
                }
            } catch (e: Exception) {
                // Xử lý lỗi nếu cần
            }
        }
    }
}

data class CourseManageUiState(
    val courseWithTeacherList : List<CourseWithTeacher> = emptyList(),
    val lessonCounts: Int = 0
)