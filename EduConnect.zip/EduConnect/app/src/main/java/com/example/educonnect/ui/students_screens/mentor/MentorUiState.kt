package com.example.educonnect.ui.students_screens.mentor

import com.example.educonnect.data.models.users.TeacherProfile

data class MentorUiState(
    val mentorList : List<TeacherProfile> = listOf()
)