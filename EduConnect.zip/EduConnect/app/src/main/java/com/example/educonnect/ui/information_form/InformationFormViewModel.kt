package com.example.educonnect.ui.information_form

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.users.TeacherProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.datetime.toJavaLocalDate
import java.lang.Exception

class InformationFormViewModel(
    private val supabase : SupabaseClient,
    private val userRepository: UserRepository
) : ViewModel() {
    private var _teacherProfileState = MutableStateFlow(InformationUiState())
    val teacherProfileState : StateFlow<InformationUiState> = _teacherProfileState.asStateFlow()

    suspend fun saveTeacherProfile(teacherProfile: TeacherProfile) {
        if (!validateInput(teacherProfile)) {
            Log.e("INFORMATION_RESULT", "Mời nhập đầy đủ thông tin")
            return
        }

        viewModelScope.launch {
            try {
//                userRepository.insertTeacherProfileStream(teacherProfile)
                supabase.from("teacher_profiles").insert(teacherProfile)
                _teacherProfileState.update { currentState ->
                    currentState.copy(
                        isFilled = true
                    )
                }
            } catch (e: Exception) {
                Log.e("TEACHER_INFORMATION_RESULT", "Lỗi: $e")
            }
        }
    }

    private fun validateInput(teacherProfile: TeacherProfile) : Boolean {
        return teacherProfile.name.isNotBlank() &&
                teacherProfile.gender.isNotEmpty() &&
                teacherProfile.number.isNotBlank() &&
                teacherProfile.dateOfBirth.toJavaLocalDate().isBefore(java.time.LocalDate.now()) &&
                teacherProfile.specialization.isNotEmpty()
    }
}