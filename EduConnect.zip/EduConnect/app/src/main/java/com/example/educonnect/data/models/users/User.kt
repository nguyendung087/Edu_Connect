package com.example.educonnect.data.models.users

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class User(
    @SerialName("user_id")
    val userId: String = "",
    val email: String = "",
    val role: String = ""
)