package com.example.educonnect.ui.mentor_screens.assignments

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.AssignmentRepository
import com.example.educonnect.data.models.courses.Assignment
import com.example.educonnect.ui.mentor_screens.planning.PlanningDestination
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

class AssignmentViewModel(
    savedStateHandle: SavedStateHandle,
    private val supabase : SupabaseClient
) : ViewModel() {
    private var _assignmentUiState = MutableStateFlow(AssignmentUiState())
    val assignmentUiState : StateFlow<AssignmentUiState> = _assignmentUiState.asStateFlow()

    private val courseId : String = checkNotNull(savedStateHandle[PlanningDestination.courseIdArg])

    init {
        loadAssignments()
    }

    private fun loadAssignments() {
        viewModelScope.launch {
            try {
                val assignments = supabase.from("assignments")
                    .select { filter { eq("course_id", courseId) } }
                    .decodeList<Assignment>()
                _assignmentUiState.update { currentState -> currentState.copy(assignments = assignments) }
            } catch (e: Exception) {
                Log.e("ASSIGNMENT_VIEWMODEL", "Error loading assignments: $e")
            }
        }
    }

    fun addAssignment(
        title: String,
        description: String,
        deadline: LocalDateTime?,
        type: String
    ) {
        viewModelScope.launch {
            try {
                val assignTime = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
                val index = getNextAssignmentNumber()
                val assignmentId = "$courseId-ASM-$type-$index"
                val newAssignment = Assignment(
                    assignmentId = assignmentId,
                    courseId = courseId,
                    title = title,
                    description = description,
                    assignTime = assignTime,
                    deadline = deadline!!,
                    type = type
                )
                supabase.from("assignments").insert(newAssignment)
                loadAssignments() // Tải lại danh sách bài tập
            } catch (e: Exception) {
                Log.e("ASSIGNMENT_VIEWMODEL", "Error adding assignment: $e")
            }
        }
    }

    private suspend fun getNextAssignmentNumber(): Int {
        val currentAssignments = supabase.from("assignments")
            .select { filter { eq("course_id", courseId) } }
            .decodeList<Assignment>()
        return currentAssignments.size + 1
    }
}

data class AssignmentUiState(
    val assignments : List<Assignment> = emptyList()
)