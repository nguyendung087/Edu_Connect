package com.example.educonnect.ui.students_screens.home

import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.users.StudentProfile
import com.example.educonnect.data.models.users.TeacherProfile

data class HomeUiState(
    var courseWithTeacherList: List<CourseWithTeacher> = listOf(),
    var mentorList : List<TeacherProfile> = listOf(),
    var currentUser : StudentProfile? = StudentProfile()
)
