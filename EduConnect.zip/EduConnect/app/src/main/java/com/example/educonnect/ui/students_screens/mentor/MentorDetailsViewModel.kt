package com.example.educonnect.ui.students_screens.mentor

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.users.Experience
import com.example.educonnect.data.models.users.TeacherProfile
import com.example.educonnect.ui.students_screens.courses.CourseDetailsUiState
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MentorDetailsViewModel(
    savedStateHandle: SavedStateHandle,
    private val supabase : SupabaseClient
) : ViewModel() {

    private var _mentorUiState = MutableStateFlow(MentorDetailsUiState())
    val mentorUiState : StateFlow<MentorDetailsUiState> = _mentorUiState.asStateFlow()

    private val teacherId : String = checkNotNull(savedStateHandle[MentorDetailsDestination.mentorIdArg])

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val teacher = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeSingle<TeacherProfile>()

                val experiences = supabase.from("experience")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeList<Experience>()

                _mentorUiState.update { it.copy(mentor = teacher, exp = experiences) }
            } catch (e: Exception) {
                Log.e("FETCH_DATA", "Error fetching data: $e")
            }
        }
    }

//    private fun loadData() {
//        viewModelScope.launch {
//            try {
//                val mentorDeferred = async { getTeacherProfile() }
//                val experienceDeferred = async { getExperience() }
//                mentorDeferred.await()
//                experienceDeferred.await()
//            } catch (e: Exception) {
//                Log.e("FETCH_DATA", "Lỗi khi lấy data: $e")
//            }
//        }
//    }
//
//    private suspend fun getTeacherProfile() {
//        userRepository.getTeacherProfileStream(teacherId).collect { mentor ->
//            _mentorUiState.update { currentState ->
//                currentState.copy(
//                    mentor = mentor
//                )
//            }
//        }
//    }
//
//    private suspend fun getExperience() {
//        userRepository.getExperiencesByTeacherStream(teacherId).collect { exp ->
//            _mentorUiState.update { currentState ->
//                currentState.copy(
//                    exp = exp
//                )
//            }
//        }
//    }
//
//
//    companion object {
//        private const val TIMEOUT_MILLIS = 5_000L
//    }
}

data class MentorDetailsUiState(
    val mentor : TeacherProfile = TeacherProfile(),
    val exp : List<Experience> = emptyList()
)