package com.example.educonnect.ui.navigation

interface NavigationDestination {
    val route : String
    val titleRes : Int
}