package com.example.educonnect.data.models.courses

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Bookmark(
    @SerialName("student_id")
    val studentId: String = "",
    @SerialName("course_id")
    val courseId: String = ""
)