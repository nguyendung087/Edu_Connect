package com.example.educonnect.data.models.courses

import com.example.educonnect.data.models.users.StudentProfile
import kotlinx.serialization.Serializable

@Serializable
data class SubmissionWithStudent(
    val submission: Submission,
    val student: StudentProfile
)