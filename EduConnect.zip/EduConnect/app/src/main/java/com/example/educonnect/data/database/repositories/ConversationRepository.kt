package com.example.educonnect.data.database.repositories

class ConversationRepository {
}