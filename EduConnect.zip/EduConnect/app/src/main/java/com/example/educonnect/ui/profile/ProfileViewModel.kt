package com.example.educonnect.ui.profile

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.users.StudentProfile
import com.example.educonnect.data.models.users.TeacherProfile
import com.google.firebase.auth.FirebaseAuth
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val supabase : SupabaseClient
) : ViewModel() {
    private val auth = FirebaseAuth.getInstance()

    private var _profileUiState = MutableStateFlow(ProfileUiState())
    val profileUiState : StateFlow<ProfileUiState> = _profileUiState.asStateFlow()

    fun getCurrentUser(userId: String?, userRole: String?) {
        if (userId == null || userRole == null) {
            _profileUiState.update { currentState ->
                currentState.copy(currentStudent = null, currentMentor = null)
            }
            return
        }

        viewModelScope.launch {
            try {
                if (userRole == "Học viên") {
                    val student = supabase.from("student_profiles")
                        .select { filter { eq("student_id", userId) } }
                        .decodeSingle<StudentProfile>()
                    _profileUiState.update { currentState ->
                        currentState.copy(currentStudent = student)
                    }
                } else {
                    val teacher = supabase.from("teacher_profiles")
                        .select { filter { eq("teacher_id", userId) } }
                        .decodeSingle<TeacherProfile>()
                    _profileUiState.update { currentState ->
                        currentState.copy(currentMentor = teacher)
                    }
                }
            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error fetching profile: $e")
                _profileUiState.update { currentState ->
                    currentState.copy(currentStudent = null, currentMentor = null)
                }
            }
        }
    }

    fun logout() {
        auth.signOut()
        _profileUiState.value = ProfileUiState()
    }
}

data class ProfileUiState(
    val currentStudent : StudentProfile? = StudentProfile(),
    val currentMentor : TeacherProfile? = TeacherProfile()
)