package com.example.educonnect.data.models.users

import kotlinx.datetime.LocalDateTime
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Notification(
    @SerialName("notification_id")
    val notificationId: String = "",
    @SerialName("user_id")
    val userId: String = "",
    val title : String = "",
    val content: String = "",
    val type: String = "",
    @SerialName("is_read")
    val isRead : Boolean = false,
    @SerialName("time_stamp")
    val timeStamp : LocalDateTime
)