package com.example.educonnect.ui.students_screens.courses

import com.example.educonnect.data.models.courses.EnrollmentWithCourseAndTeacher

data class CourseUiState(
    val currentUserId : String? = "",
    val enrollment: List<EnrollmentWithCourseAndTeacher> = emptyList()
)
