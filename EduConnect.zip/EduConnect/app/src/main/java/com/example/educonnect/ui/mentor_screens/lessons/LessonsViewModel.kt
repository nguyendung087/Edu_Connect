package com.example.educonnect.ui.mentor_screens.lessons

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.models.courses.Lesson
import com.example.educonnect.ui.mentor_screens.planning.PlanningDestination
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class LessonsViewModel(
    savedStateHandle: SavedStateHandle,
    private val supabase : SupabaseClient
) : ViewModel() {
    private var _courseUiState = MutableStateFlow(CourseManageDetailsUiState())
    val courseUiState : StateFlow<CourseManageDetailsUiState> = _courseUiState.asStateFlow()

    private val courseId : String = checkNotNull(savedStateHandle[PlanningDestination.courseIdArg])

    init {
        loadLessonsByCourse()
    }

    private fun loadLessonsByCourse() {
        viewModelScope.launch {
            try {
                val lessons = supabase.from("lessons")
                    .select { filter { eq("course_id", courseId) } }
                    .decodeList<Lesson>()
                _courseUiState.update { currentState -> currentState.copy(lessons = lessons) }
            } catch (e: Exception) {
                Log.e("LessonsViewModel", "Error fetching lessons: $e")
            }
        }
    }

    fun addLesson(title: String, content: String) {
        viewModelScope.launch {
            try {
                val lessonNumber = getNextLessonNumber()
                val lessonId = "${courseId}-${lessonNumber}"
                val newLesson = Lesson(
                    lessonId = lessonId,
                    courseId = courseId,
                    title = title,
                    content = content,
                    type = "Documents",
                    fileUrl = "abc"
                )
                supabase.from("lessons").insert(newLesson)
                loadLessonsByCourse() // Tải lại danh sách bài học
            } catch (e: Exception) {
                Log.e("ADD_LESSON", "Error adding lesson: $e")
            }
        }
    }

    private suspend fun getNextLessonNumber(): Int {
        val currentLessons = supabase.from("lessons")
            .select { filter { eq("course_id", courseId) } }
            .decodeList<Lesson>()
        return currentLessons.size + 1
    }

    fun removeLesson(lessonId: String) {
        viewModelScope.launch {
            try {
                supabase.from("lessons").delete {
                    filter { eq("lesson_id", lessonId) }
                }
                loadLessonsByCourse() // Tải lại danh sách bài học
            } catch (e: Exception) {
                Log.e("REMOVE_LESSON", "Error removing lesson: $e")
            }
        }
    }

    fun updateUiState(lesson: Lesson) {
        _courseUiState.update { currentState -> currentState.copy(lesson = lesson) }
    }

    suspend fun updateLesson() {
        _courseUiState.value.lesson.let {
            supabase.from("lessons").update(it) {
                filter { eq("lesson_id", it.lessonId) }
            }
            loadLessonsByCourse() // Tải lại danh sách bài học
        }
    }
}

data class CourseManageDetailsUiState(
    val lessons : List<Lesson> = emptyList(),
    val lesson : Lesson = Lesson()
)