package com.example.educonnect.ui.mentor_screens.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.users.TeacherProfile
import com.example.educonnect.ui.students_screens.home.HomeUiState
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MentorHomeViewModel(
    private val supabase : SupabaseClient
) : ViewModel() {

    private var _homeUiState = MutableStateFlow(MentorHomeUiState())
    val homeUiState : StateFlow<MentorHomeUiState> = _homeUiState.asStateFlow()

    fun loadUser(userId: String?) {
        if (userId == null) {
            _homeUiState.update { currentState -> currentState.copy(currentUser = null) }
            return
        }

        viewModelScope.launch {
            try {
                val teacher = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", userId) } }
                    .decodeSingle<TeacherProfile>()
                _homeUiState.update { currentState -> currentState.copy(currentUser = teacher) }
            } catch (e: Exception) {
                Log.e("MENTOR_HOME_VIEWMODEL", "Error fetching teacher profile: $e")
                _homeUiState.update { currentState -> currentState.copy(currentUser = null) }
            }
        }
    }

    fun getCoursesWithTeachersList(teacherId: String?) {
        if (teacherId == null) return

        viewModelScope.launch {
            try {
                val courses = supabase.from("courses")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeList<Course>()

                val teachers = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", teacherId) } }
                    .decodeList<TeacherProfile>()

                val courseWithTeachers = courses.map { course ->
                    val teacher = teachers.find { it.teacherId == course.teacherId }
                    CourseWithTeacher(course, teacher ?: TeacherProfile())
                }

                _homeUiState.update { currentState ->
                    currentState.copy(courseWithTeacherList = courseWithTeachers)
                }
            } catch (e: Exception) {
                Log.e("MENTOR_HOME_VIEWMODEL", "Error fetching courses: $e")
            }
        }
    }

    fun getEnrollmentsByCourse() {

    }
}

data class MentorHomeUiState(
    val currentUser : TeacherProfile? = TeacherProfile(),
    val courseWithTeacherList : List<CourseWithTeacher> = emptyList()
)