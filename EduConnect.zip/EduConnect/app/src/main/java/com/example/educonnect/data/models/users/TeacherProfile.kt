package com.example.educonnect.data.models.users

import kotlinx.datetime.LocalDate
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TeacherProfile(
    @SerialName("teacher_id")
    val teacherId: String = "",
    val name: String = "",
    @SerialName("avatar_url")
    val avatarUrl: String = "",
    @SerialName("date_of_birth")
    val dateOfBirth: LocalDate = LocalDate(1990, 1, 1),
    val number: String = "",
    val gender: String = "",
    val specialization: String = ""
)