package com.example.educonnect.ui.students_screens.bookmark

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.BookmarkRepository
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.courses.Bookmark
import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.users.TeacherProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BookmarkViewModel(
    private val supabase : SupabaseClient
) : ViewModel() {
    private val _bookmarkUiState = MutableStateFlow(BookmarkUiState())
    val bookmarkUiState: StateFlow<BookmarkUiState> = _bookmarkUiState.asStateFlow()

    fun updateUserId(userId: String?) {
        _bookmarkUiState.update { it.copy(currentUserId = userId) }
    }

    fun loadBookmarkedCourses(studentId: String?) {
        if (studentId == null) return
        viewModelScope.launch {
            try {
                val bookmarks = supabase.from("bookmarks")
                    .select { filter { eq("student_id", studentId) } }
                    .decodeList<Bookmark>()

                val courseIds = bookmarks.map { it.courseId }
                val courses = supabase.from("courses")
                    .select { filter { eq("course_id", courseIds) } }
                    .decodeList<Course>()

                val teachers = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", courses.map { it.teacherId }) } }
                    .decodeList<TeacherProfile>()

                val bookmarkedCourses = courses.map { course ->
                    val teacher = teachers.find { it.teacherId == course.teacherId }
                    CourseWithTeacher(course, teacher!!)
                }

                _bookmarkUiState.update { it.copy(bookmarkedCourses = bookmarkedCourses) }
            } catch (e: Exception) {
                Log.e("BOOKMARK_VIEWMODEL", "Error fetching bookmarked courses: $e")
            }
        }
    }

    fun addBookmark(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("bookmarks").insert(
                    Bookmark(
                        studentId = studentId,
                        courseId = courseId
                    )
                )
            } catch (e: Exception) {
                Log.e("ADD_BOOKMARK", "Error adding bookmark: $e")
            }
        }
    }

    fun removeBookmark(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("bookmarks").delete {
                    filter { eq("student_id", studentId); eq("course_id", courseId) }
                }
            } catch (e: Exception) {
                Log.e("REMOVE_BOOKMARK", "Error removing bookmark: $e")
            }
        }
    }

    fun isCourseBookmarked(studentId: String, courseId: String): Flow<Boolean> {
        return flow {
            try {
                val bookmarks = supabase.from("bookmarks")
                    .select { filter { eq("student_id", studentId) } }
                    .decodeList<Bookmark>()
                emit(bookmarks.any { it.courseId == courseId })
            } catch (e: Exception) {
                Log.e("IS_BOOKMARKED", "Error checking bookmark: $e")
                emit(false)
            }
        }
    }

//    fun updateUserId(userId : String?) {
//        _bookmarkUiState.update { currentState ->
//            currentState.copy(
//                currentUserId = userId
//            )
//        }
//    }
//
//    fun loadBookmarkedCourses(studentId: String?) {
//        viewModelScope.launch {
//            bookmarkRepository.getBookmarkedCourses(studentId).collect { courses ->
//                _bookmarkUiState.update { it.copy(bookmarkedCourses = courses) }
//            }
//        }
//    }
//
//    fun addBookmark(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            bookmarkRepository.insertBookmark(Bookmark(studentId, courseId))
//        }
//    }
//
//    fun removeBookmark(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            bookmarkRepository.deleteBookmark(Bookmark(studentId, courseId))
//        }
//    }
//
//    fun isCourseBookmarked(studentId: String, courseId: String): Flow<Boolean> {
//        return bookmarkRepository.getBookmarksByStudent(studentId)
//            .map { bookmarks ->
//                bookmarks.any {
//                    it.courseId == courseId
//                }
//            }
//    }
}

data class BookmarkUiState(
    val bookmarkedCourses: List<CourseWithTeacher> = emptyList(),
    val currentUserId : String? = ""
)