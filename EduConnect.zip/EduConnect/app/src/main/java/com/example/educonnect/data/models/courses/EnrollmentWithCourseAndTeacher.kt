package com.example.educonnect.data.models.courses

import com.example.educonnect.data.models.users.TeacherProfile
import kotlinx.serialization.Serializable

@Serializable
data class EnrollmentWithCourseAndTeacher(
    val enrollment: Enrollment,
    val course: Course,
    val teacher: TeacherProfile
)