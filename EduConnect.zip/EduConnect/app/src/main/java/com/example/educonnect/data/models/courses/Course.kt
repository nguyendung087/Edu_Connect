package com.example.educonnect.data.models.courses

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Course(
    @SerialName("course_id")
    val courseId: String = "",
    @SerialName("teacher_id")
    val teacherId: String = "",
    val title: String = "",
    val description : String = "",
    @SerialName("course_image")
    val courseImage: String = "",
    val cost: Double = 0.0,

)