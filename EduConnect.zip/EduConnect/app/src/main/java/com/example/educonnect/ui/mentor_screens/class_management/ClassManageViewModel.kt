package com.example.educonnect.ui.mentor_screens.class_management

class ClassManageViewModel {
}