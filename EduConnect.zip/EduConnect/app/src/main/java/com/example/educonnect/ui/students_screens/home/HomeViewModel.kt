package com.example.educonnect.ui.students_screens.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.SampleData
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.users.StudentProfile
import com.example.educonnect.data.models.users.TeacherProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(
    private val supabase : SupabaseClient,
    private val userRepository: UserRepository,
    private val courseRepository: CourseRepository,
) : ViewModel() {

    private var _homeUiState = MutableStateFlow(HomeUiState())
    val homeUiState : StateFlow<HomeUiState> = _homeUiState.asStateFlow()

    private val storageBaseUrl = "https://zpdurqxwndlkjcvagvqu.supabase.co/storage/v1/object/public/course_images/"

    init {
        loadData()
    }

    fun loadUser(userId: String?) {
        if (userId == null) {
            _homeUiState.update { currentState ->
                currentState.copy(currentUser = null)
            }
            return
        }

        viewModelScope.launch {
            try {
                val studentProfile = supabase.from("student_profiles")
                    .select {
                        filter { eq("student_id", userId) }
                    }
                    .decodeSingleOrNull<StudentProfile>()
                _homeUiState.update { currentState ->
                    currentState.copy(currentUser = studentProfile)
                }
            } catch (e: Exception) {
                Log.e("HomeViewModel", "Lỗi khi lấy student profile: $e")
                _homeUiState.update { currentState ->
                    currentState.copy(currentUser = null)
                }
            }
        }
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val coursesDeferred = async { getCoursesWithTeachersList() }
                val mentorDeferred = async { getMentorList() }
                coursesDeferred.await()
                mentorDeferred.await()
            } catch (e: Exception) {
                Log.e("FETCH_DATA", "Lỗi khi lấy data: $e")
            }
        }
    }

    private suspend fun getCoursesWithTeachersList() {
        try {
            val courses = supabase.from("courses")
                .select()
                .decodeList<Course>()
            val courseWithTeachers = courses.map { course ->
                val teacher = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", course.teacherId) } }
                    .decodeSingleOrNull<TeacherProfile>()
                    ?: TeacherProfile(teacherId = course.teacherId, name = "Unknown")
                // Construct full image URL
                val courseWithFullUrl = course.copy(
                    courseImage = if (course.courseImage.startsWith("http")) {
                        course.courseImage
                    } else {
                        "$storageBaseUrl${course.courseImage}"
                    }
                )
                CourseWithTeacher(courseWithFullUrl, teacher)
            }
            _homeUiState.update { currentState ->
                currentState.copy(courseWithTeacherList = courseWithTeachers)
            }
        } catch (e: Exception) {
            Log.e("HomeViewModel", "Lỗi khi lấy courses: $e")
        }
    }

    private suspend fun getMentorList() {
        try {
            val mentors = supabase.from("teacher_profiles")
                .select()
                .decodeList<TeacherProfile>()
            _homeUiState.update { currentState ->
                currentState.copy(mentorList = mentors)
            }
        } catch (e: Exception) {
            Log.e("HomeViewModel", "Lỗi khi lấy mentor list: $e")
        }
    }

    fun insertBulkUsers() {
        val userList = SampleData.users
        viewModelScope.launch {
            try {
                userRepository.insertAllUserStream(userList)
            } catch (ex: Exception) {
                Log.e("HomeViewModel", "Lỗi khi chèn users", ex)
            }
        }
    }

    fun insertBulkTeacherProfiles() {
        val teacherList = SampleData.teachers
        viewModelScope.launch {
            try {
                userRepository.insertAllTeacherProfileStream(teacherList)
            } catch (ex: Exception) {
                Log.e("HomeViewModel", "Lỗi khi chèn teacher profiles", ex)
            }
        }
    }

    fun insertBulkCourses() {
        val courseList = SampleData.courses
        viewModelScope.launch {
            try {
                courseRepository.insertAllCoursesStream(courseList)
            } catch (ex: Exception) {
                Log.e("HomeViewModel", "Lỗi khi chèn course", ex)
            }
        }
    }

    fun insertBulkExperience() {
        val expList = SampleData.experiences
        viewModelScope.launch {
            try {
                userRepository.insertExperienceStream(expList)
            } catch (ex: Exception) {
                Log.e("HomeViewModel", "Lỗi khi chèn exp", ex)
            }
        }
    }

    fun insertBulkLessons() {
        val lessonList = SampleData.lessons
        viewModelScope.launch {
            try {
                courseRepository.insertLessonStream(lessonList)
            } catch (e : Exception) {
                Log.e("HomeViewModel", "Lỗi khi chèn lessons", e)
            }
        }
    }
}
