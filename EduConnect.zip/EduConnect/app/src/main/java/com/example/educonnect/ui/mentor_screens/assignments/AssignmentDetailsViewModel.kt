package com.example.educonnect.ui.mentor_screens.assignments

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.AssignmentRepository
import com.example.educonnect.data.database.repositories.SubmissionRepository
import com.example.educonnect.data.models.courses.Assignment
import com.example.educonnect.data.models.courses.Lesson
import com.example.educonnect.data.models.courses.SubmissionWithStudent
import com.example.educonnect.data.models.courses.Submission
import com.example.educonnect.data.models.users.StudentProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AssignmentDetailsViewModel(
    savedStateHandle: SavedStateHandle,
    private val supabase :SupabaseClient
) : ViewModel() {
    private var _assignmentUiState = MutableStateFlow(AssignmentDetailsUiState())
    val assignmentUiState : StateFlow<AssignmentDetailsUiState> = _assignmentUiState.asStateFlow()

    private val assignmentId : String = checkNotNull(savedStateHandle[AssignmentDetailsDestination.assignmentIdArg])

    init {
        loadAssignment()
        loadSubmissionWithStudents()
    }

    private fun loadAssignment() {
        viewModelScope.launch {
            try {
                val assignment = supabase.from("assignments")
                    .select { filter { eq("assignment_id", assignmentId) } }
                    .decodeSingle<Assignment>()
                _assignmentUiState.update { currentState -> currentState.copy(assignment = assignment) }
            } catch (e: Exception) {
                Log.e("ASSIGNMENT_DETAILS_VIEWMODEL", "Error loading assignment: $e")
            }
        }
    }

    private fun loadSubmissionWithStudents() {
        viewModelScope.launch {
            try {
                val submissions = supabase.from("submissions")
                    .select { filter { eq("assignment_id", assignmentId) } }
                    .decodeList<Submission>()

                val studentIds = submissions.map { it.studentId }
                val students = supabase.from("student_profiles")
                    .select { filter { eq("student_id", studentIds) } }
                    .decodeList<StudentProfile>()

                val submissionWithStudents = submissions.map { submission ->
                    val student = students.find { it.studentId == submission.studentId }
                    SubmissionWithStudent(submission, student ?: StudentProfile())
                }

                _assignmentUiState.update { currentState -> currentState.copy(submissionWithStudent = submissionWithStudents) }
            } catch (e: Exception) {
                Log.e("ASSIGNMENT_DETAILS_VIEWMODEL", "Error loading submissions: $e")
            }
        }
    }

    fun deleteAssignment() {
        viewModelScope.launch {
            try {
                supabase.from("assignments").delete {
                    filter { eq("assignment_id", assignmentId) }
                }
            } catch (e: Exception) {
                Log.e("REMOVE_ASSIGNMENT", "Error deleting assignment: $e")
            }
        }
    }

    fun updateUiState(assignment: Assignment) {
        _assignmentUiState.update { currentState -> currentState.copy(assignment = assignment) }
    }

    suspend fun updateLesson() {
        _assignmentUiState.value.assignment.let {
            supabase.from("assignments").update(it) {
                filter { eq("assignment_id", it.assignmentId) }
            }
        }
    }
}

data class AssignmentDetailsUiState(
    val submissionWithStudent: List<SubmissionWithStudent> = emptyList() ,
    val assignment: Assignment = Assignment()
)