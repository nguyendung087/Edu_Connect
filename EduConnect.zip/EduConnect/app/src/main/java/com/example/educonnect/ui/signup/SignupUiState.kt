package com.example.educonnect.ui.signup

data class SignupUiState (
    val currentUserId : String = ""
)
