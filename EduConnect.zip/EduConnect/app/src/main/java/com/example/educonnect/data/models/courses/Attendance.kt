package com.example.educonnect.data.models.courses

import kotlinx.datetime.LocalDateTime
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Attendance(
    @SerialName("student_id")
    val studentId: String = "",

    @SerialName("lesson_id")
    val lessonId: String = "",

    @SerialName("join_time")
    val joinTime: LocalDateTime,

    @SerialName("leave_time")
    val leaveTime: LocalDateTime
)