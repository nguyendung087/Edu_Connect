package com.example.educonnect.data.models.users

import kotlinx.datetime.LocalDate
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Experience(
    @SerialName("experience_id")
    val experienceId: String = "",
    @SerialName("teacher_id")
    val teacherId: String = "",
    @SerialName("company_name")
    val companyName: String = "",
    val position: String = "",
    @SerialName("start_date")
    val startDate: LocalDate = LocalDate(1990, 1, 1),
    @SerialName("end_date")
    val endDate: LocalDate = LocalDate(1990, 1, 1),
    val description: String = ""
)