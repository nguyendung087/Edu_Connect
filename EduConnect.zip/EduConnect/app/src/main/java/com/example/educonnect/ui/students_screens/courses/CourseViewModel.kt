package com.example.educonnect.ui.students_screens.courses

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.model.courses.CourseWithTeacher
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.courses.Enrollment
import com.example.educonnect.data.models.courses.EnrollmentWithCourseAndTeacher
import com.example.educonnect.data.models.users.TeacherProfile
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CourseViewModel(
    private val supabase : SupabaseClient,
    private val courseRepository: CourseRepository,
    private val userRepository: UserRepository
) : ViewModel() {
    private var _courseUiState = MutableStateFlow(CourseUiState())
    val courseUiState : StateFlow<CourseUiState> = _courseUiState.asStateFlow()

    fun getCurrentUserEnrollment(userId: String?) {
        if (userId == null) {
            _courseUiState.update { it.copy(currentUserId = null) }
            return
        }

        viewModelScope.launch {
            try {
                val enrollments = supabase.from("enrollments")
                    .select { filter { eq("student_id", userId) } }
                    .decodeList<Enrollment>()

                val courseIds = enrollments.map { it.courseId }
                val courses = supabase.from("courses")
                    .select { filter { eq("course_id", courseIds) } }
                    .decodeList<Course>()

                val teacherIds = courses.map { it.teacherId }
                val teachers = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", teacherIds) } }
                    .decodeList<TeacherProfile>()

                val enrollmentWithCourseAndTeacher = enrollments.map { enrollment ->
                    val course = courses.find { it.courseId == enrollment.courseId }
                    val teacher = teachers.find { it.teacherId == course?.teacherId }
                    EnrollmentWithCourseAndTeacher(enrollment, course!!, teacher!!)
                }

                _courseUiState.update { it.copy(enrollment = enrollmentWithCourseAndTeacher) }
            } catch (e: Exception) {
                Log.e("COURSE_VIEWMODEL", "Lỗi khi lấy enrollment: $e")
            }
        }
    }
}