package com.example.educonnect.ui.students_screens.mentor

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.UserRepository
import com.example.educonnect.data.model.chat.Conversation
import com.example.educonnect.data.models.users.TeacherProfile
import com.google.firebase.Firebase
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.database
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID

class TopMentorViewModel(
    private val supabase : SupabaseClient
) : ViewModel() {

    val mentorUiState: StateFlow<MentorUiState> = flow {
        try {
            val teachers = supabase.from("teacher_profiles").select().decodeList<TeacherProfile>()
            emit(MentorUiState(teachers))
        } catch (e: Exception) {
            Log.e("TOP_MENTOR_VIEWMODEL", "Error fetching mentor list: $e")
            emit(MentorUiState())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(TIMEOUT_MILLIS),
        initialValue = MentorUiState()
    )

    fun getOrCreateConversation(studentId: String, teacherId: String, onComplete: (String) -> Unit) {
        val db = FirebaseDatabase.getInstance()
        if (studentId.isEmpty() || teacherId.isEmpty()) {
            Log.e("EduConnectDB", "studentId hoặc teacherId rỗng")
            return
        }

        Log.d("EduConnectDB", "Bắt đầu truy vấn conversation cho studentId: $studentId")

        db.getReference("conversation")
            .orderByChild("studentId")
            .equalTo(studentId)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val snapshot = task.result

                    Log.d("EduConnectDB", "Truy vấn hoàn thành. task.isSuccessful: ${task.isSuccessful}")
                    Log.d("EduConnectDB", "Snapshot exists: ${snapshot.exists()}")
                    Log.d("EduConnectDB", "Snapshot value: ${snapshot.value}")

                    if (snapshot.exists()) {
                        val conversation = snapshot.children.firstOrNull { childSnapshot ->
                            childSnapshot.child("teacherId").value == teacherId
                        }

                        if (conversation != null) {
                            val conversationId = conversation.key
                            if (conversationId != null) {
                                Log.d("EduConnectDB", "Tìm thấy cuộc trò chuyện cũ với ID: $conversationId")
                                onComplete(conversationId)
                            } else {
                                Log.e("EduConnectDB", "Tìm thấy snapshot nhưng key bị null")
                                createNewConversation(studentId, teacherId, onComplete)
                            }
                        } else {
                            Log.d("EduConnectDB", "Không tìm thấy cuộc trò chuyện khớp teacherId. Tạo mới...")
                            createNewConversation(studentId, teacherId, onComplete)
                        }
                    } else {
                        Log.d("EduConnectDB", "Snapshot không tồn tại cho studentId này. Tạo mới...")
                        createNewConversation(studentId, teacherId, onComplete)
                    }
                } else {
                    Log.e("EduConnectDB", "Lỗi truy vấn conversation: ${task.exception?.message}")
                    createNewConversation(studentId, teacherId, onComplete)
                }
            }
            .addOnFailureListener { e ->
                Log.e("EduConnectDB", "addOnFailureListener được gọi. Lỗi khi truy vấn conversation: ${e.message}", e)
            }
    }

    fun createNewConversation(studentId: String, teacherId: String, onComplete: (String) -> Unit) {
        viewModelScope.launch {
            val db = Firebase.database
            Log.d("EduConnectDB", "Chuẩn bị tạo cuộc trò chuyện mới giữa $studentId và $teacherId")
            val newConversation = mapOf(
                "studentId" to studentId,
                "teacherId" to teacherId,
                "createdAt" to LocalDateTime.now().toString(),
                "updatedAt" to LocalDateTime.now().toString()
            )
            val key = db.getReference("conversation").push().key
            if (key == null) {
                Log.e("EduConnectDB", "Không tạo được key mới cho cuộc trò chuyện")
                return@launch
            }
            Log.d("EduConnectDB", "Đang tạo cuộc trò chuyện mới với key: $key")
            db.getReference("conversation").child(key).setValue(newConversation)
                .addOnSuccessListener {
                    Log.d("EduConnectDB", "Tạo cuộc trò chuyện thành công: $key")
                    onComplete(key)
                }
                .addOnFailureListener { e ->
                    Log.e("EduConnectDB", "Lỗi khi GHI cuộc trò chuyện mới với key $key: ${e.message}", e)
                }
        }
    }


    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}