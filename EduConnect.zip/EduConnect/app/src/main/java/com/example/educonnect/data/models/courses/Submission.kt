package com.example.educonnect.data.models.courses

import kotlinx.datetime.LocalDateTime
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Submission(
    @SerialName("submission_id") val submissionId: String,
    @SerialName("assignment_id") val assignmentId: String,
    @SerialName("student_id") val studentId: String,
    @SerialName("submission_time") val submissionTime: LocalDateTime,
    val content: String
)