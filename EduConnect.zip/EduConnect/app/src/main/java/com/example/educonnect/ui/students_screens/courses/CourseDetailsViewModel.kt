package com.example.educonnect.ui.students_screens.courses

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.educonnect.data.database.repositories.BookmarkRepository
import com.example.educonnect.data.database.repositories.CourseRepository
import com.example.educonnect.data.models.courses.Bookmark
import com.example.educonnect.data.models.courses.CourseWithTeacher
import com.example.educonnect.data.models.courses.Enrollment
import com.example.educonnect.data.models.courses.Lesson
import com.example.educonnect.data.models.courses.Course
import com.example.educonnect.data.models.users.TeacherProfile
import com.example.educonnect.ui.students_screens.bookmark.BookmarkViewModel
import com.example.educonnect.ui.students_screens.home.HomeUiState
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CourseDetailsViewModel(
    savedStateHandle: SavedStateHandle,
    private val supabase : SupabaseClient,
) : ViewModel() {

    private var _courseUiState = MutableStateFlow(CourseDetailsUiState())
    val courseUiState : StateFlow<CourseDetailsUiState> = _courseUiState.asStateFlow()

    private val courseId : String = checkNotNull(savedStateHandle[CourseDetailsDestination.courseIdArg])

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val course = supabase.from("courses")
                    .select { filter { eq("course_id", courseId) } }
                    .decodeSingle<Course>()

                val teacher = supabase.from("teacher_profiles")
                    .select { filter { eq("teacher_id", course.teacherId) } }
                    .decodeSingle<TeacherProfile>()

                val lessons = supabase.from("lessons")
                    .select { filter { eq("course_id", courseId) } }
                    .decodeList<Lesson>()

                _courseUiState.update {
                    it.copy(
                        courseDetails = CourseWithTeacher(course, teacher),
                        lessons = lessons
                    )
                }
            } catch (e: Exception) {
                Log.e("FETCH_DATA_COURSE_DETAILS", "Error fetching data: $e")
            }
        }
    }

    fun enrollCourse(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("enrollments").insert(
                    Enrollment(
                        studentId = studentId,
                        courseId = courseId,
                        status = "Ongoing",
                        progress = 0.0f
                    )
                )
            } catch (e: Exception) {
                Log.e("ENROLL_COURSE_DETAILS", "Error enrolling course: $e")
            }
        }
    }

    fun removeEnrollment(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("enrollments").delete {
                    filter { eq("student_id", studentId); eq("course_id", courseId) }
                }
            } catch (e: Exception) {
                Log.e("REMOVE_ENROLLMENT_COURSE_DETAILS", "Error removing enrollment: $e")
            }
        }
    }

    fun addBookmark(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("bookmarks").insert(
                    Bookmark(
                        studentId = studentId,
                        courseId = courseId
                    )
                )
            } catch (e: Exception) {
                Log.e("ADD_BOOKMARK_COURSE_DETAILS", "Error adding bookmark: $e")
            }
        }
    }

    fun removeBookmark(studentId: String, courseId: String) {
        viewModelScope.launch {
            try {
                supabase.from("bookmarks").delete {
                    filter { eq("student_id", studentId); eq("course_id", courseId) }
                }
            } catch (e: Exception) {
                Log.e("REMOVE_BOOKMARK_COURSE_DETAILS", "Error removing bookmark: $e")
            }
        }
    }

    fun isCourseBookmarked(studentId: String, courseId: String): Flow<Boolean> {
        return flow {
            try {
                val bookmarks = supabase.from("bookmarks")
                    .select { filter { eq("student_id", studentId) } }
                    .decodeList<Bookmark>()
                emit(bookmarks.any { it.courseId == courseId })
            } catch (e: Exception) {
                Log.e("IS_BOOKMARKED_COURSE_DETAILS", "Error checking bookmark: $e")
                emit(false)
            }
        }
    }

    fun isUserEnrolled(studentId: String, courseId: String): Flow<Boolean> {
        return flow {
            try {
                val enrollments = supabase.from("enrollments")
                    .select { filter { eq("student_id", studentId) } }
                    .decodeList<Enrollment>()
                emit(enrollments.any { it.courseId == courseId })
            } catch (e: Exception) {
                Log.e("IS_ENROLLED_COURSE_DETAILS", "Error checking enrollment: $e")
                emit(false)
            }
        }
    }

//    fun enrollCourse(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            courseRepository.insertEnrollmentStream(
//                Enrollment(
//                    courseId = courseId,
//                    studentId = studentId,
//                )
//            )
//        }
//    }
//
//    fun removeEnrollment(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            courseRepository.deleteEnrollmentStream(
//                Enrollment(
//                    courseId = courseId,
//                    studentId = studentId
//                )
//            )
//        }
//    }
//
//    fun addBookmark(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            bookmarkRepository.insertBookmark(Bookmark(studentId, courseId))
//        }
//    }
//
//    fun removeBookmark(studentId: String, courseId: String) {
//        viewModelScope.launch {
//            bookmarkRepository.deleteBookmark(Bookmark(studentId, courseId))
//        }
//    }
//
//    private fun loadData() {
//        viewModelScope.launch {
//            try {
//                val coursesDeferred = async { getCourseWithTeacherByCourse() }
//                val lessonDeferred = async { getLessonsByCourse() }
//                coursesDeferred.await()
//                lessonDeferred.await()
//            } catch (e: Exception) {
//                Log.e("FETCH_DATA", "Lỗi khi lấy data: $e")
//            }
//        }
//    }
//
//    private suspend fun getCourseWithTeacherByCourse() {
//        courseRepository.getCourseWithTeacherByCourseStream(courseId).collect { course ->
//            _courseUiState.update { currentState ->
//                currentState.copy(
//                    courseDetails = course
//                )
//            }
//        }
//    }
//
//    private suspend fun getLessonsByCourse() {
//        courseRepository.getAllLessonsByCourseStream(courseId).collect { lessons ->
//            _courseUiState.update { currentState ->
//                currentState.copy(
//                    lessons = lessons
//                )
//            }
//        }
//    }
//
//    fun isCourseBookmarked(studentId: String, courseId: String): Flow<Boolean> {
//        return bookmarkRepository.getBookmarksByStudent(studentId)
//            .map { bookmarks ->
//                bookmarks.any {
//                    it.courseId == courseId
//                }
//            }
//    }
//
//    fun isUserEnrolled(studentId: String, courseId: String): Flow<Boolean> {
//        return courseRepository.getEnrollmentsByUserStream(studentId)
//            .map { enrollments ->
//                enrollments.any { it.courseId == courseId }
//            }
//    }
}

data class CourseDetailsUiState(
    val courseDetails : CourseWithTeacher = CourseWithTeacher(),
    val lessons : List<Lesson> = listOf(),
    val enrollment : Enrollment = Enrollment(),
    val isEnrolled : Boolean = false
)